/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testbancario;


/**
 *
 * @author mpumbulula.chakenane
 */
public class TestBancario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ContoCorrente cc = new ContoCorrente("nome", 3240);
        System.out.println(cc + " - "  + cc.getConto() + " - " + cc.getContocorrente());
        
        
        
        
        
    }
    
}
